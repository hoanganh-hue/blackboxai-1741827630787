import { Configuration, OpenAIApi } from 'openai';
import { ChatGPTConfig, ChatGPTResponse } from '../interfaces/chatgpt.interface';
import { ApiError } from '../middleware/error.middleware';

export class ChatGPTService {
  private openai: OpenAIApi;
  private defaultConfig: ChatGPTConfig = {
    model: "text-davinci-003",
    temperature: 0.7,
    max_tokens: 2000,
    top_p: 1,
    frequency_penalty: 0,
    presence_penalty: 0
  };

  constructor() {
    const configuration = new Configuration({
      apiKey: process.env.OPENAI_API_KEY,
    });
    this.openai = new OpenAIApi(configuration);
  }

  async generateResponse(
    message: string, 
    config: Partial<ChatGPTConfig> = {}
  ): Promise<ChatGPTResponse> {
    try {
      const completion = await this.openai.createCompletion({
        ...this.defaultConfig,
        ...config,
        prompt: message,
      });
      
      return {
        text: completion.data.choices[0].text || 'No response available',
        usage: completion.data.usage
      };
    } catch (error: any) {
      throw new ApiError(
        error.response?.status || 500,
        error.response?.data?.error?.message || 'Error calling ChatGPT API'
      );
    }
  }
}