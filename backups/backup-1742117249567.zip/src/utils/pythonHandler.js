const { spawn } = require('child_process');
const path = require('path');
const logger = require('./logger');

class PythonHandler {
    constructor() {
        this.pythonPath = process.env.PYTHON_PATH || 'python3';
        this.scriptPath = path.join(__dirname, '../python');
    }

    async executeScript(scriptName, args = []) {
        return new Promise((resolve, reject) => {
            const scriptPath = path.join(this.scriptPath, scriptName);
            const pythonProcess = spawn(this.pythonPath, [scriptPath, ...args]);
            
            let output = '';
            let error = '';

            pythonProcess.stdout.on('data', (data) => {
                output += data.toString();
                logger.info(`Python output: ${data}`);
            });

            pythonProcess.stderr.on('data', (data) => {
                error += data.toString();
                logger.error(`Python error: ${data}`);
            });

            pythonProcess.on('close', (code) => {
                if (code !== 0) {
                    reject(new Error(`Python script exited with code ${code}: ${error}`));
                } else {
                    try {
                        const result = JSON.parse(output);
                        resolve(result);
                    } catch (e) {
                        resolve(output);
                    }
                }
            });
        });
    }

    async analyzeFile(filePath) {
        return this.executeScript('analyze_file.py', [filePath]);
    }

    async processData(data) {
        return this.executeScript('process_data.py', [JSON.stringify(data)]);
    }

    async executeCommand(command) {
        return this.executeScript('execute_command.py', [command]);
    }
}

module.exports = PythonHandler; 