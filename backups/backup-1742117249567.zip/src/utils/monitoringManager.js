const os = require('os');
const pidusage = require('pidusage');
const AdvancedLogger = require('./advancedLogger');

class MonitoringManager {
    constructor(wsManager) {
        this.wsManager = wsManager;
        this.logger = new AdvancedLogger();
        this.monitoringInterval = null;
        this.subscribers = new Set();
    }

    startMonitoring(interval = 5000) {
        if (this.monitoringInterval) {
            return;
        }

        this.monitoringInterval = setInterval(async () => {
            try {
                const metrics = await this.collectMetrics();
                this.broadcastMetrics(metrics);
            } catch (error) {
                this.logger.error('Error collecting metrics:', error);
            }
        }, interval);
    }

    stopMonitoring() {
        if (this.monitoringInterval) {
            clearInterval(this.monitoringInterval);
            this.monitoringInterval = null;
        }
    }

    async collectMetrics() {
        const cpus = os.cpus();
        const totalMemory = os.totalmem();
        const freeMemory = os.freemem();
        const usedMemory = totalMemory - freeMemory;
        const memoryUsage = (usedMemory / totalMemory * 100).toFixed(2);

        // Collect process metrics
        const processMetrics = await pidusage(process.pid);

        return {
            timestamp: Date.now(),
            system: {
                cpu: {
                    cores: cpus.length,
                    model: cpus[0].model,
                    speed: cpus[0].speed,
                    loadavg: os.loadavg()
                },
                memory: {
                    total: totalMemory,
                    free: freeMemory,
                    used: usedMemory,
                    usage: memoryUsage
                },
                uptime: os.uptime()
            },
            process: {
                cpu: processMetrics.cpu.toFixed(2),
                memory: processMetrics.memory,
                uptime: processMetrics.elapsed
            }
        };
    }

    broadcastMetrics(metrics) {
        this.wsManager.broadcast({
            type: 'metrics',
            data: metrics
        });
    }

    subscribe(clientId) {
        this.subscribers.add(clientId);
        if (this.subscribers.size === 1) {
            this.startMonitoring();
        }
    }

    unsubscribe(clientId) {
        this.subscribers.delete(clientId);
        if (this.subscribers.size === 0) {
            this.stopMonitoring();
        }
    }
}

module.exports = MonitoringManager; 