const { spawn } = require('child_process');
const { v4: uuidv4 } = require('uuid');
const { EventEmitter } = require('events');
const logger = require('./logger');

class CommandManager extends EventEmitter {
    constructor(wsManager) {
        super();
        this.wsManager = wsManager;
        this.activeCommands = new Map();
        this.commandHistory = [];
    }

    async executeCommand(command, options = {}) {
        const id = uuidv4();
        const { workingDir, timeout } = options;

        return new Promise((resolve, reject) => {
            try {
                const startTime = Date.now();
                const child = spawn(command, [], {
                    shell: true,
                    cwd: workingDir
                });

                this.activeCommands.set(id, {
                    process: child,
                    command,
                    startTime,
                    output: []
                });

                let output = '';
                let error = '';

                child.stdout.on('data', (data) => {
                    const text = data.toString();
                    output += text;
                    this.emit('commandOutput', { id, output: text });
                    this.wsManager.broadcast({
                        type: 'command-output',
                        id,
                        output: text
                    });
                });

                child.stderr.on('data', (data) => {
                    const text = data.toString();
                    error += text;
                    this.emit('commandError', { id, error: text });
                    this.wsManager.broadcast({
                        type: 'command-error',
                        id,
                        error: text
                    });
                });

                child.on('close', (code) => {
                    const endTime = Date.now();
                    const duration = endTime - startTime;

                    const result = {
                        id,
                        command,
                        code,
                        output,
                        error,
                        duration,
                        startTime,
                        endTime
                    };

                    this.commandHistory.push(result);
                    this.activeCommands.delete(id);

                    this.emit('commandComplete', result);
                    this.wsManager.broadcast({
                        type: 'command-complete',
                        ...result
                    });

                    if (code === 0) {
                        resolve(result);
                    } else {
                        reject(new Error(`Command failed with code ${code}`));
                    }
                });

                if (timeout) {
                    setTimeout(() => {
                        if (this.activeCommands.has(id)) {
                            this.stopCommand(id);
                            this.emit('commandTimeout', { id });
                            reject(new Error('Command timed out'));
                        }
                    }, timeout);
                }
            } catch (error) {
                this.emit('commandError', { id, error: error.message });
                reject(error);
            }
        });
    }

    stopCommand(id) {
        const command = this.activeCommands.get(id);
        if (command) {
            command.process.kill();
            this.activeCommands.delete(id);
            this.emit('commandStopped', { id });
            logger.info(`Stopped command: ${id}`);
            return true;
        }
        return false;
    }

    stopAllCommands() {
        this.activeCommands.forEach((command, id) => {
            this.stopCommand(id);
        });
        this.emit('allCommandsStopped');
    }

    getActiveCommands() {
        const commands = [];
        this.activeCommands.forEach((command, id) => {
            commands.push({
                id,
                command: command.command,
                startTime: command.startTime,
                duration: Date.now() - command.startTime
            });
        });
        return commands;
    }

    getCommandHistory(limit = 100) {
        return this.commandHistory.slice(-limit);
    }
}

module.exports = CommandManager; 