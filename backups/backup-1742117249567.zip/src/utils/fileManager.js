const fs = require('fs-extra');
const path = require('path');
const yaml = require('js-yaml');
const crypto = require('crypto');
const { promisify } = require('util');
const pipeline = promisify(require('stream').pipeline);
const logger = require('./logger');

class FileManager {
    constructor(logger) {
        this.logger = logger;
        this.CHUNK_SIZE = 5 * 1024 * 1024; // 5MB chunks
    }

    async checkAccess(filePath) {
        try {
            await fs.access(filePath);
            return true;
        } catch {
            return false;
        }
    }

    async exists(filePath) {
        return fs.pathExists(filePath);
    }

    async readFile(filePath, options = {}) {
        const stats = await fs.stat(filePath);
        
        if (stats.size > this.CHUNK_SIZE && !options.force) {
            return this.readLargeFile(filePath, stats.size);
        }

        try {
            const content = await fs.readFile(filePath, 'utf-8');
            const ext = path.extname(filePath).toLowerCase();

            if (!content.trim()) {
                return { type: 'Empty', message: 'Empty file' };
            }

            switch (ext) {
                case '.json':
                    return { type: 'JSON', content: JSON.parse(content) };
                case '.yaml':
                case '.yml':
                    return { type: 'YAML', content: yaml.load(content) };
                default:
                    return { type: 'Text', content };
            }
        } catch (error) {
            this.logger.error(`File read error (${filePath}):`, error);
            throw error;
        }
    }

    async readLargeFile(filePath, totalSize) {
        const chunks = [];
        const stream = fs.createReadStream(filePath, { highWaterMark: this.CHUNK_SIZE });

        return new Promise((resolve, reject) => {
            stream.on('data', chunk => chunks.push(chunk));
            stream.on('end', () => resolve(Buffer.concat(chunks)));
            stream.on('error', reject);
        });
    }

    async writeFile(filePath, content, options = {}) {
        try {
            let finalContent = content;

            if (typeof content === 'object') {
                if (path.extname(filePath) === '.yaml') {
                    finalContent = yaml.dump(content);
                } else {
                    finalContent = JSON.stringify(content, null, 2);
                }
            }

            await fs.writeFile(filePath, finalContent, options);
            this.logger.info(`File written: ${filePath}`);
            return true;
        } catch (error) {
            this.logger.error(`File write error (${filePath}):`, error);
            throw error;
        }
    }

    async writeLargeFile(filePath, content) {
        const writeStream = fs.createWriteStream(filePath);
        await pipeline(content, writeStream);
        this.logger.info(`Large file written: ${filePath}`);
    }

    async listFiles(directory, options = { recursive: false }) {
        try {
            const files = await fs.readdir(directory);
            const fileList = [];

            for (const file of files) {
                const filePath = path.join(directory, file);
                const stats = await fs.stat(filePath);
                
                fileList.push({
                    name: file,
                    path: filePath,
                    size: stats.size,
                    isDirectory: stats.isDirectory(),
                    created: stats.birthtime,
                    modified: stats.mtime
                });

                if (options.recursive && stats.isDirectory()) {
                    const subFiles = await this.listFiles(filePath, options);
                    fileList.push(...subFiles);
                }
            }

            return fileList;
        } catch (error) {
            this.logger.error(`Error listing files: ${error.message}`);
            throw error;
        }
    }

    async copyFile(source, destination, options = {}) {
        try {
            await fs.copy(source, destination, options);
            this.logger.info(`File copied: ${source} -> ${destination}`);
            return true;
        } catch (error) {
            this.logger.error(`File copy error:`, error);
            throw error;
        }
    }

    async moveFile(sourcePath, destPath) {
        try {
            await fs.move(sourcePath, destPath, { overwrite: true });
            this.logger.info(`Moved file from ${sourcePath} to ${destPath}`);
            return true;
        } catch (error) {
            this.logger.error(`Error moving file: ${error.message}`);
            throw error;
        }
    }

    async deleteFile(filePath) {
        try {
            await fs.remove(filePath);
            this.logger.info(`Deleted file: ${filePath}`);
            return true;
        } catch (error) {
            this.logger.error(`Error deleting file: ${error.message}`);
            throw error;
        }
    }

    async calculateHash(filePath, algorithm = 'sha256') {
        const hash = crypto.createHash(algorithm);
        const stream = fs.createReadStream(filePath);

        return new Promise((resolve, reject) => {
            stream.on('error', reject);
            stream.on('data', chunk => hash.update(chunk));
            stream.on('end', () => resolve(hash.digest('hex')));
        });
    }
}

module.exports = FileManager;