const fs = require('fs-extra');
const path = require('path');
const yaml = require('js-yaml');
const AdvancedLogger = require('./advancedLogger');

class FileAnalyzer {
    constructor(logger) {
        this.logger = logger || new AdvancedLogger();
        this.fileTypes = {
            '.txt': { type: 'text', handler: this.analyzeTextFile.bind(this) },
            '.log': { type: 'text', handler: this.analyzeTextFile.bind(this) },
            '.md': { type: 'markdown', handler: this.analyzeTextFile.bind(this) },
            '.js': { type: 'javascript', handler: this.analyzeJavaScriptFile.bind(this) },
            '.json': { type: 'json', handler: this.analyzeJsonFile.bind(this) },
            '.yaml': { type: 'yaml', handler: this.analyzeYamlFile.bind(this) },
            '.csv': { type: 'csv', handler: this.analyzeCsvFile.bind(this) },
            '.html': { type: 'html', handler: this.analyzeHtmlFile.bind(this) },
            '.py': { type: 'python', handler: this.analyzePythonFile.bind(this) }
        };
    }

    async analyzeFile(filePath) {
        try {
            const exists = await fs.pathExists(filePath);
            if (!exists) {
                throw new Error(`File not found: ${filePath}`);
            }

            const stats = await fs.stat(filePath);
            const ext = path.extname(filePath).toLowerCase();
            const fileType = this.fileTypes[ext] || { type: 'unknown', handler: this.analyzeUnknownFile.bind(this) };

            const analysisResults = await fileType.handler(filePath);
            this.logger.info(`Analyzed file: ${filePath}`, analysisResults);

            return {
                path: filePath,
                name: path.basename(filePath),
                extension: ext,
                type: fileType.type,
                size: stats.size,
                created: stats.birthtime,
                modified: stats.mtime,
                accessed: stats.atime,
                analysis: analysisResults
            };

        } catch (error) {
            this.logger.error(`Error analyzing file ${filePath}:`, error);
            throw error;
        }
    }

    async analyzeTextFile(filePath) {
        const content = await fs.readFile(filePath, 'utf8');
        const lines = content.split('\n');
        return {
            lineCount: lines.length,
            charCount: content.length,
            wordCount: content.split(/\s+/).length,
            isEmpty: content.trim().length === 0,
            previewContent: content.slice(0, 1000)
        };
    }

    async analyzeJsonFile(filePath) {
        const content = await fs.readFile(filePath, 'utf8');
        try {
            const parsed = JSON.parse(content);
            return {
                isValid: true,
                structure: this.analyzeStructure(parsed),
                size: content.length,
                previewContent: content.slice(0, 1000)
            };
        } catch (error) {
            return {
                isValid: false,
                error: error.message,
                previewContent: content.slice(0, 1000)
            };
        }
    }

    async analyzeYamlFile(filePath) {
        const content = await fs.readFile(filePath, 'utf8');
        try {
            const parsed = yaml.load(content);
            return {
                isValid: true,
                structure: this.analyzeStructure(parsed),
                size: content.length,
                previewContent: content.slice(0, 1000)
            };
        } catch (error) {
            return {
                isValid: false,
                error: error.message,
                previewContent: content.slice(0, 1000)
            };
        }
    }

    async analyzeCsvFile(filePath) {
        const content = await fs.readFile(filePath, 'utf8');
        const lines = content.split('\n').filter(line => line.trim());
        const headers = lines[0].split(',').map(h => h.trim());
        const data = lines.slice(1).map(line => line.split(',').map(cell => cell.trim()));
        
        return {
            lineCount: lines.length,
            columnCount: headers.length,
            headers: headers,
            rowCount: data.length,
            previewContent: content.slice(0, 1000)
        };
    }

    async analyzeHtmlFile(filePath) {
        const content = await fs.readFile(filePath, 'utf8');
        const divCount = (content.match(/<div/g) || []).length;
        const hasDoctype = content.toLowerCase().includes('<!doctype');
        const hasHead = content.toLowerCase().includes('<head');
        const hasBody = content.toLowerCase().includes('<body');
        
        return {
            size: content.length,
            divCount: divCount,
            hasDoctype: hasDoctype,
            hasHead: hasHead,
            hasBody: hasBody,
            previewContent: content.slice(0, 1000)
        };
    }

    async analyzePythonFile(filePath) {
        const content = await fs.readFile(filePath, 'utf8');
        const lines = content.split('\n');
        
        const analysis = {
            imports: [],
            classes: [],
            functions: [],
            variables: [],
            lineCount: lines.length,
            commentCount: 0
        };

        for (let line of lines) {
            const trimmedLine = line.trim();
            
            if (trimmedLine.startsWith('import ') || trimmedLine.startsWith('from ')) {
                analysis.imports.push(trimmedLine);
            }
            else if (trimmedLine.startsWith('class ')) {
                analysis.classes.push(trimmedLine.split('class ')[1].split('(')[0].trim());
            }
            else if (trimmedLine.startsWith('def ')) {
                analysis.functions.push(trimmedLine.split('def ')[1].split('(')[0].trim());
            }
            else if (trimmedLine.startsWith('#')) {
                analysis.commentCount++;
            }
        }

        return {
            ...analysis,
            previewContent: content.slice(0, 1000)
        };
    }

    async analyzeJavaScriptFile(filePath) {
        const content = await fs.readFile(filePath, 'utf8');
        const lines = content.split('\n');
        
        const analysis = {
            imports: [],
            exports: [],
            classes: [],
            functions: [],
            variables: [],
            lineCount: lines.length,
            commentCount: 0,
            hasAsync: false
        };

        for (let line of lines) {
            const trimmedLine = line.trim();
            
            if (trimmedLine.startsWith('import ')) {
                analysis.imports.push(trimmedLine);
            }
            else if (trimmedLine.startsWith('export ')) {
                analysis.exports.push(trimmedLine);
            }
            else if (trimmedLine.startsWith('class ')) {
                analysis.classes.push(trimmedLine.split('class ')[1].split(' ')[0]);
            }
            else if (trimmedLine.startsWith('function ') || trimmedLine.includes('async function')) {
                const funcName = trimmedLine.includes('async function') ? 
                    trimmedLine.split('async function ')[1].split('(')[0] :
                    trimmedLine.split('function ')[1].split('(')[0];
                analysis.functions.push(funcName);
                if (trimmedLine.includes('async')) {
                    analysis.hasAsync = true;
                }
            }
            else if (trimmedLine.startsWith('//')) {
                analysis.commentCount++;
            }
        }

        return {
            ...analysis,
            previewContent: content.slice(0, 1000)
        };
    }

    analyzeUnknownFile(filePath) {
        return {
            message: 'Unknown file type',
            suggestion: 'Consider adding a specific analyzer for this file type'
        };
    }

    analyzeStructure(obj, depth = 0, maxDepth = 3) {
        if (depth >= maxDepth) return '...';
        
        if (Array.isArray(obj)) {
            return `Array(${obj.length})`;
        }
        
        if (typeof obj === 'object' && obj !== null) {
            const structure = {};
            for (const [key, value] of Object.entries(obj)) {
                structure[key] = this.analyzeStructure(value, depth + 1, maxDepth);
            }
            return structure;
        }
        
        return typeof obj;
    }
}

module.exports = FileAnalyzer; 