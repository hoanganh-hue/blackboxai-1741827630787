
import express from 'express';
import { chatCompletion } from '../controllers/chat.controller';

const router = express.Router();

router.post('/completion', chatCompletion);

export default router;