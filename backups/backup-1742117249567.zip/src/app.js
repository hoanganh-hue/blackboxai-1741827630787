require('dotenv').config();
const express = require('express');
const http = require('http');
const WebSocket = require('ws');
const path = require('path');
const multer = require('multer');
const fs = require('fs-extra');
const logger = require('./utils/logger');

const WebSocketManager = require('./utils/webSocketManager');
const CommandManager = require('./utils/commandManager');
const FileManager = require('./utils/fileManager');
const FileAnalyzer = require('./utils/fileAnalyzer');
const PythonHandler = require('./utils/pythonHandler');
const MonitoringManager = require('./utils/monitoringManager');

const systemRoutes = require('./api/routes/systemRoutes');
const fileRoutes = require('./api/routes/fileRoutes');
const pythonRoutes = require('./api/routes/pythonRoutes');
const guiRoutes = require('./api/routes/guiRoutes');
const analyzeRoutes = require('./api/routes/analyzeRoutes');
const processRoutes = require('./api/routes/processRoutes');
const backupRoutes = require('./api/routes/backupRoutes');

const { errorHandler } = require('./middleware/errorHandler');
const { apiLimiter, heavyApiLimiter } = require('./middleware/rateLimit');

// Initialize Express and create HTTP server
const app = express();
const server = http.createServer(app);

// Initialize WebSocket first
const wsManager = new WebSocketManager(server);

// Then initialize other managers that depend on WebSocket
const commandManager = new CommandManager(wsManager);
const fileManager = new FileManager(logger);
const fileAnalyzer = new FileAnalyzer(logger);
const pythonHandler = new PythonHandler();
const monitoringManager = new MonitoringManager(wsManager);

// Make managers available to routes
app.set('wsManager', wsManager);
app.set('commandManager', commandManager);
app.set('fileManager', fileManager);
app.set('fileAnalyzer', fileAnalyzer);
app.set('pythonHandler', pythonHandler);
app.set('monitoringManager', monitoringManager);

// Middleware
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Apply rate limiting to all routes
app.use(apiLimiter);

// Configure multer for file uploads
const upload = multer({
    dest: path.join(__dirname, '../uploads/'),
    limits: { fileSize: 100 * 1024 * 1024 } // 100MB limit
});

// Ensure required directories exist
fs.ensureDirSync(path.join(__dirname, '../logs'));
fs.ensureDirSync(path.join(__dirname, '../uploads'));
fs.ensureDirSync(path.join(__dirname, '../backups'));

// Routes
app.use('/api/system', systemRoutes);
app.use('/api/files', fileRoutes);
app.use('/api/python', pythonRoutes);
app.use('/api/gui', guiRoutes);
app.use('/api/analyze', analyzeRoutes);
app.use('/api/process', processRoutes);
app.use('/api/backup', backupRoutes);

// Root route
app.get('/', (req, res) => {
    res.json({ 
        message: 'Server is running',
        status: 'OK',
        version: require('../package.json').version
    });
});

// WebSocket connection handling
wsManager.wss.on('connection', (ws, req) => {
    const clientId = req.headers['sec-websocket-key'];
    
    ws.on('message', (message) => {
        try {
            const data = JSON.parse(message);
            
            switch (data.type) {
                case 'subscribe':
                    monitoringManager.subscribe(clientId);
                    break;
                case 'unsubscribe':
                    monitoringManager.unsubscribe(clientId);
                    break;
                default:
                    logger.warn('Unknown WebSocket message type:', data.type);
            }
        } catch (error) {
            logger.error('WebSocket message error:', error);
        }
    });

    ws.on('close', () => {
        monitoringManager.unsubscribe(clientId);
    });
});

// Error handling middleware
app.use(errorHandler);

// Handle process termination
process.on('SIGTERM', () => {
    logger.info('SIGTERM received. Shutting down gracefully...');
    monitoringManager.stopMonitoring();
    commandManager.stopAllCommands();
    server.close(() => {
        logger.info('Server closed');
        process.exit(0);
    });
});

// Start server
const port = process.env.PORT || 3000;
server.listen(port, () => {
    logger.info(`Server is running on port ${port}`);
});

module.exports = server; 