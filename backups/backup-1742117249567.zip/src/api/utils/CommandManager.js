const { spawn } = require('child_process');
const EventEmitter = require('events');
const logger = require('./logger');

class CommandManager extends EventEmitter {
    constructor(wsManager) {
        super();
        this.activeCommands = new Map(); // Lưu trữ các lệnh đang chạy
        this.commandHistory = new Map(); // Lưu trữ lịch sử lệnh
        this.wsManager = wsManager;
    }

    /**
     * Thực thi một lệnh
     * @param {string} command - Lệnh cần thực thi
     * @param {Object} options - Các tùy chọn
     * @param {string} options.workingDir - Thư mục làm việc
     * @param {boolean} options.background - Chạy trong background
     * @param {number} options.timeout - Thời gian timeout (ms)
     * @returns {Promise<Object>} Kết quả thực thi
     */
    execute(command, options = {}) {
        return new Promise((resolve, reject) => {
            const commandId = Date.now().toString();
            let output = '';
            let errorOutput = '';

            const spawnOptions = {
                shell: true,
                cwd: options.workingDir || process.cwd(),
                detached: options.background || false
            };

            const child = spawn(command, [], spawnOptions);
            
            // Lưu thông tin command
            const commandInfo = {
                id: commandId,
                command,
                options,
                startTime: new Date(),
                status: 'running',
                pid: child.pid
            };

            this.activeCommands.set(commandId, commandInfo);

            // Thông báo trạng thái qua WebSocket
            if (this.wsManager) {
                this.wsManager.broadcastCommandStatus(commandId, {
                    status: 'started',
                    command: commandInfo
                });
            }

            // Xử lý output
            child.stdout.on('data', (data) => {
                const chunk = data.toString();
                output += chunk;

                // Gửi output qua WebSocket
                if (this.wsManager) {
                    this.wsManager.broadcastCommandOutput(commandId, {
                        output: chunk,
                        type: 'stdout'
                    });
                }

                this.emit('commandOutput', {
                    id: commandId,
                    output: chunk,
                    type: 'stdout'
                });
            });

            child.stderr.on('data', (data) => {
                const chunk = data.toString();
                errorOutput += chunk;

                // Gửi error output qua WebSocket
                if (this.wsManager) {
                    this.wsManager.broadcastCommandOutput(commandId, {
                        output: chunk,
                        type: 'stderr'
                    });
                }

                this.emit('commandOutput', {
                    id: commandId,
                    output: chunk,
                    type: 'stderr'
                });
            });

            // Xử lý khi command kết thúc
            child.on('close', (code) => {
                const endTime = new Date();
                const duration = endTime - commandInfo.startTime;

                // Cập nhật thông tin command
                commandInfo.status = code === 0 ? 'completed' : 'failed';
                commandInfo.endTime = endTime;
                commandInfo.duration = duration;
                commandInfo.exitCode = code;

                // Lưu vào lịch sử
                this.commandHistory.set(commandId, {
                    ...commandInfo,
                    output,
                    errorOutput
                });

                // Xóa khỏi danh sách active nếu không chạy background
                if (!options.background) {
                    this.activeCommands.delete(commandId);
                }

                // Thông báo kết thúc qua WebSocket
                if (this.wsManager) {
                    this.wsManager.broadcastCommandStatus(commandId, {
                        status: code === 0 ? 'completed' : 'failed',
                        duration,
                        exitCode: code
                    });
                }

                // Emit event
                this.emit('commandComplete', {
                    id: commandId,
                    exitCode: code,
                    duration
                });

                // Resolve/reject promise
                if (code === 0) {
                    resolve({
                        id: commandId,
                        output,
                        errorOutput,
                        duration,
                        exitCode: code
                    });
                } else {
                    reject(new Error(`Command failed with exit code ${code}`));
                }
            });

            // Xử lý timeout
            if (options.timeout) {
                setTimeout(() => {
                    if (this.activeCommands.has(commandId)) {
                        child.kill();
                        this.activeCommands.delete(commandId);

                        // Thông báo timeout qua WebSocket
                        if (this.wsManager) {
                            this.wsManager.broadcastCommandStatus(commandId, {
                                status: 'timeout'
                            });
                        }

                        reject(new Error('Command timeout'));
                    }
                }, options.timeout);
            }

            // Xử lý lỗi
            child.on('error', (error) => {
                this.activeCommands.delete(commandId);

                // Thông báo lỗi qua WebSocket
                if (this.wsManager) {
                    this.wsManager.broadcastCommandStatus(commandId, {
                        status: 'error',
                        error: error.message
                    });
                }

                reject(error);
            });

            // Nếu chạy background, resolve ngay
            if (options.background) {
                resolve({
                    id: commandId,
                    pid: child.pid,
                    background: true
                });
            }
        });
    }

    /**
     * Lấy danh sách các lệnh đang chạy
     * @returns {Array} Danh sách lệnh
     */
    getActiveCommands() {
        return Array.from(this.activeCommands.values());
    }

    /**
     * Lấy lịch sử lệnh
     * @param {number} limit - Số lượng lệnh tối đa
     * @returns {Array} Lịch sử lệnh
     */
    getCommandHistory(limit = 100) {
        const history = Array.from(this.commandHistory.values());
        return history.slice(-limit);
    }

    /**
     * Dừng một lệnh đang chạy
     * @param {string} commandId - ID của lệnh
     * @returns {boolean} Kết quả dừng lệnh
     */
    stopCommand(commandId) {
        const command = this.activeCommands.get(commandId);
        if (command && command.pid) {
            try {
                process.kill(command.pid);
                this.activeCommands.delete(commandId);

                // Thông báo dừng lệnh qua WebSocket
                if (this.wsManager) {
                    this.wsManager.broadcastCommandStatus(commandId, {
                        status: 'stopped'
                    });
                }

                return true;
            } catch (error) {
                // Nếu process không tồn tại, vẫn xóa khỏi danh sách active
                if (error.code === 'ESRCH') {
                    this.activeCommands.delete(commandId);
                    logger.info(`Command ${commandId} was already completed`);
                    return true;
                }
                logger.error(`Error stopping command ${commandId}:`, error);
                return false;
            }
        }
        return false;
    }

    /**
     * Dừng tất cả các lệnh đang chạy
     */
    stopAllCommands() {
        for (const [commandId] of this.activeCommands) {
            this.stopCommand(commandId);
        }
    }

    // Thêm phương thức để cập nhật WebSocket Manager
    setWebSocketManager(wsManager) {
        this.wsManager = wsManager;
    }
}

module.exports = CommandManager; 