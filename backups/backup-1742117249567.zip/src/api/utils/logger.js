const winston = require('winston');
const path = require('path');

// Định nghĩa format log
const logFormat = winston.format.combine(
    winston.format.timestamp(),
    winston.format.json()
);

// Tạo logger instance
const logger = winston.createLogger({
    level: 'info',
    format: logFormat,
    transports: [
        // Ghi log ra console
        new winston.transports.Console({
            format: winston.format.combine(
                winston.format.colorize(),
                winston.format.simple()
            )
        }),
        // Ghi log error vào file
        new winston.transports.File({
            filename: path.join('logs', 'error.log'),
            level: 'error'
        }),
        // Ghi tất cả các log vào file
        new winston.transports.File({
            filename: path.join('logs', 'combined.log')
        })
    ]
});

module.exports = logger; 