
const { spawn } = require('child_process');
const path = require('path');

class PythonExecutor {
    constructor() {
        this.baseDir = path.join(__dirname, '../../executors');
    }

    execute(scriptPath, params) {
        return new Promise((resolve, reject) => {
            const fullPath = path.join(this.baseDir, scriptPath);
            const python = spawn('python3', [fullPath, JSON.stringify(params)]);
            
            let output = '';
            let error = '';

            python.stdout.on('data', (data) => {
                output += data.toString();
            });

            python.stderr.on('data', (data) => {
                error += data.toString();
            });

            python.on('close', (code) => {
                if (code !== 0) {
                    reject(new Error(error || 'Python execution failed'));
                    return;
                }
                try {
                    resolve(JSON.parse(output));
                } catch (e) {
                    reject(new Error('Invalid JSON output from Python script'));
                }
            });
        });
    }
}

module.exports = { PythonExecutor };