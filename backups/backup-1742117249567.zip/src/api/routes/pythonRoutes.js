const express = require('express');
const router = express.Router();
const PythonHandler = require('../../utils/pythonHandler');
const AdvancedLogger = require('../../utils/advancedLogger');

const logger = new AdvancedLogger();
const pythonHandler = new PythonHandler(logger);

// Analyze file
router.post('/analyze', async (req, res) => {
    try {
        const { filePath } = req.body;
        if (!filePath) {
            return res.status(400).json({ error: 'File path is required' });
        }
        const result = await pythonHandler.analyzeFile(filePath);
        res.json(result);
    } catch (error) {
        logger.error('Error in Python analysis:', error);
        res.status(500).json({ error: error.message });
    }
});

// Process data
router.post('/process', async (req, res) => {
    try {
        const { data, options } = req.body;
        if (!data) {
            return res.status(400).json({ error: 'Data is required' });
        }
        const result = await pythonHandler.processData(data, options);
        res.json(result);
    } catch (error) {
        logger.error('Error in Python processing:', error);
        res.status(500).json({ error: error.message });
    }
});

// Execute Python script
router.post('/execute', async (req, res) => {
    try {
        const { script, args } = req.body;
        if (!script) {
            return res.status(400).json({ error: 'Script is required' });
        }
        const result = await pythonHandler.executeScript(script, args);
        res.json(result);
    } catch (error) {
        logger.error('Error executing Python script:', error);
        res.status(500).json({ error: error.message });
    }
});

module.exports = router; 