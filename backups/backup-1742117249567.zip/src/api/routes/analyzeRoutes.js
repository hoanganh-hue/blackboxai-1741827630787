const express = require('express');
const router = express.Router();
const FileAnalyzer = require('../../utils/fileAnalyzer');
const AdvancedLogger = require('../../utils/advancedLogger');

const logger = new AdvancedLogger();
const fileAnalyzer = new FileAnalyzer(logger);

router.post('/file', async (req, res) => {
    try {
        const { filePath } = req.body;
        if (!filePath) {
            return res.status(400).json({ error: 'File path is required' });
        }

        const analysis = await fileAnalyzer.analyzeFile(filePath);
        res.json(analysis);
    } catch (error) {
        logger.error('Error analyzing file:', error);
        res.status(500).json({ error: error.message });
    }
});

module.exports = router; 