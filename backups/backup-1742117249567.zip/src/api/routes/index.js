
const fileRoutes = require('./fileRoutes');
const systemRoutes = require('./systemRoutes');
const guiRoutes = require('./guiRoutes');

module.exports = (app) => {
    app.use('/api/files', fileRoutes);
    app.use('/api/system', systemRoutes);
    app.use('/api/gui', guiRoutes);
};