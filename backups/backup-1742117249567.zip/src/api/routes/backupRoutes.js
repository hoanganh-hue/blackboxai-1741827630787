const express = require('express');
const router = express.Router();
const path = require('path');
const fs = require('fs-extra');
const archiver = require('archiver');
const unzipper = require('unzipper');
const { v4: uuidv4 } = require('uuid');
const multer = require('multer');
const { AppError } = require('../../middleware/errorHandler');
const { heavyApiLimiter } = require('../../middleware/rateLimit');
const { cache } = require('../../middleware/cache');
const AdvancedLogger = require('../../utils/advancedLogger');

const logger = new AdvancedLogger();
const backupDir = path.join(__dirname, '../../../backups');

// Ensure backup directory exists
fs.ensureDirSync(backupDir);

// Configure multer for backup file uploads
const storage = multer.diskStorage({
    destination: backupDir,
    filename: (req, file, cb) => {
        const uniqueName = `backup-${Date.now()}-${uuidv4()}.zip`;
        cb(null, uniqueName);
    }
});

const upload = multer({
    storage,
    limits: { fileSize: 1024 * 1024 * 100 } // 100MB limit
});

// Create backup
router.post('/create', heavyApiLimiter, async (req, res, next) => {
    try {
        const backupName = `backup-${Date.now()}.zip`;
        const backupPath = path.join(backupDir, backupName);
        const output = fs.createWriteStream(backupPath);
        const archive = archiver('zip', { zlib: { level: 9 } });

        output.on('close', () => {
            res.json({
                message: 'Backup created successfully',
                name: backupName,
                size: archive.pointer(),
                path: backupPath
            });
        });

        archive.on('error', (err) => {
            throw new AppError('Backup creation failed', 500, 'BACKUP_CREATE_ERROR');
        });

        archive.pipe(output);

        // Add directories to backup
        archive.directory(path.join(__dirname, '../../../uploads'), 'uploads');
        archive.directory(path.join(__dirname, '../../../logs'), 'logs');
        archive.directory(path.join(__dirname, '../../../src'), 'src');

        await archive.finalize();
    } catch (error) {
        next(new AppError('Failed to create backup', 500, 'BACKUP_CREATE_ERROR'));
    }
});

// List backups
router.get('/list', heavyApiLimiter, cache(30), async (req, res, next) => {
    try {
        const files = await fs.readdir(backupDir);
        const backups = await Promise.all(
            files.filter(file => file.endsWith('.zip')).map(async file => {
                const stats = await fs.stat(path.join(backupDir, file));
                return {
                    name: file,
                    size: stats.size,
                    created: stats.birthtime
                };
            })
        );

        res.json(backups);
    } catch (error) {
        next(new AppError('Failed to list backups', 500, 'BACKUP_LIST_ERROR'));
    }
});

// Restore from backup
router.post('/restore/:filename', heavyApiLimiter, async (req, res, next) => {
    try {
        const { filename } = req.params;
        const backupPath = path.join(backupDir, filename);

        if (!await fs.pathExists(backupPath)) {
            return next(new AppError('Backup file not found', 404, 'BACKUP_NOT_FOUND'));
        }

        // Clear existing directories
        await fs.emptyDir(path.join(__dirname, '../../../uploads'));
        await fs.emptyDir(path.join(__dirname, '../../../logs'));

        // Extract backup
        await fs.createReadStream(backupPath)
            .pipe(unzipper.Extract({ path: path.join(__dirname, '../../..') }))
            .promise();

        res.json({ message: 'Backup restored successfully' });
    } catch (error) {
        next(new AppError('Failed to restore backup', 500, 'BACKUP_RESTORE_ERROR'));
    }
});

// Delete backup
router.delete('/:filename', heavyApiLimiter, async (req, res, next) => {
    try {
        const { filename } = req.params;
        const backupPath = path.join(backupDir, filename);

        if (!await fs.pathExists(backupPath)) {
            return next(new AppError('Backup file not found', 404, 'BACKUP_NOT_FOUND'));
        }

        await fs.remove(backupPath);
        res.json({ message: 'Backup deleted successfully' });
    } catch (error) {
        next(new AppError('Failed to delete backup', 500, 'BACKUP_DELETE_ERROR'));
    }
});

module.exports = router; 