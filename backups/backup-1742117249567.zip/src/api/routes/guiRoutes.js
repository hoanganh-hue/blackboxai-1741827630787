const express = require('express');
const router = express.Router();
const { Builder } = require('selenium-webdriver');
const path = require('path');
const { spawn } = require('child_process');
const AdvancedLogger = require('../../utils/advancedLogger');

const logger = new AdvancedLogger();
let driver;

// Open browser
router.post('/open', async (req, res) => {
    try {
        const { url } = req.body;
        if (!url) {
            return res.status(400).json({ error: 'URL is required' });
        }

        driver = await new Builder().forBrowser('chrome').build();
        await driver.get(url);
        res.json({ message: 'Browser opened', url });
    } catch (error) {
        logger.error('Error opening browser:', error);
        res.status(500).json({ error: error.message });
    }
});

// Close browser
router.post('/close', async (req, res) => {
    try {
        if (driver) {
            await driver.quit();
            driver = null;
            res.json({ message: 'Browser closed' });
        } else {
            res.status(400).json({ error: 'No browser session active' });
        }
    } catch (error) {
        logger.error('Error closing browser:', error);
        res.status(500).json({ error: error.message });
    }
});

// Navigate to URL
router.post('/navigate', async (req, res) => {
    try {
        const { url } = req.body;
        if (!url) {
            return res.status(400).json({ error: 'URL is required' });
        }
        if (!driver) {
            return res.status(400).json({ error: 'No browser session active' });
        }

        await driver.get(url);
        res.json({ message: 'Navigated to URL', url });
    } catch (error) {
        logger.error('Error navigating:', error);
        res.status(500).json({ error: error.message });
    }
});

// Take screenshot
router.post('/screenshot', async (req, res) => {
    try {
        if (!driver) {
            return res.status(400).json({ error: 'No browser session active' });
        }

        const screenshot = await driver.takeScreenshot();
        const filename = `screenshot-${Date.now()}.png`;
        const filepath = path.join(__dirname, '../../uploads', filename);
        
        require('fs').writeFileSync(filepath, screenshot, 'base64');
        res.json({ message: 'Screenshot taken', filename, path: filepath });
    } catch (error) {
        logger.error('Error taking screenshot:', error);
        res.status(500).json({ error: error.message });
    }
});

// Get page source
router.get('/source', async (req, res) => {
    try {
        if (!driver) {
            return res.status(400).json({ error: 'No browser session active' });
        }

        const source = await driver.getPageSource();
        res.json({ source });
    } catch (error) {
        logger.error('Error getting page source:', error);
        res.status(500).json({ error: error.message });
    }
});

// Get current URL
router.get('/url', async (req, res) => {
    try {
        if (!driver) {
            return res.status(400).json({ error: 'No browser session active' });
        }

        const url = await driver.getCurrentUrl();
        res.json({ url });
    } catch (error) {
        logger.error('Error getting current URL:', error);
        res.status(500).json({ error: error.message });
    }
});

module.exports = router; 