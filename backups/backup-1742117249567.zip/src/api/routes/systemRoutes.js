const express = require('express');
const router = express.Router();
const os = require('os');
const AdvancedLogger = require('../../utils/advancedLogger');

const logger = new AdvancedLogger();

// System info
router.get('/info', async (req, res) => {
    try {
        const systemInfo = {
            hostname: os.hostname(),
            platform: os.platform(),
            release: os.release(),
            arch: os.arch(),
            cpus: os.cpus(),
            memory: {
                total: os.totalmem(),
                free: os.freemem(),
                used: os.totalmem() - os.freemem()
            },
            network: os.networkInterfaces(),
            uptime: os.uptime(),
            loadavg: os.loadavg(),
            userInfo: os.userInfo(),
            currentDir: process.cwd()
        };
        res.json(systemInfo);
    } catch (error) {
        logger.error('Error getting system info:', error);
        res.status(500).json({ error: error.message });
    }
});

// Performance monitoring
router.get('/performance', async (req, res) => {
    try {
        const performance = {
            cpu: os.cpus(),
            memory: {
                total: os.totalmem(),
                free: os.freemem(),
                usage: ((os.totalmem() - os.freemem()) / os.totalmem() * 100).toFixed(2)
            },
            loadavg: os.loadavg()
        };
        res.json(performance);
    } catch (error) {
        logger.error('Error getting performance data:', error);
        res.status(500).json({ error: error.message });
    }
});

// Execute command
router.post('/execute', async (req, res) => {
    try {
        const { command } = req.body;
        if (!command) {
            return res.status(400).json({ error: 'Command is required' });
        }

        const commandManager = req.app.get('commandManager');
        if (!commandManager) {
            return res.status(500).json({ error: 'Command manager not initialized' });
        }

        const result = await commandManager.executeCommand(command);
        res.json(result);
    } catch (error) {
        logger.error('Error executing command:', error);
        res.status(500).json({ error: error.message });
    }
});

// Stop command
router.post('/stop/:id', async (req, res) => {
    try {
        const { id } = req.params;
        const commandManager = req.app.get('commandManager');
        if (!commandManager) {
            return res.status(500).json({ error: 'Command manager not initialized' });
        }
        await commandManager.stopCommand(id);
        res.json({ message: 'Command stopped successfully' });
    } catch (error) {
        logger.error('Error stopping command:', error);
        res.status(500).json({ error: error.message });
    }
});

// Stop all commands
router.post('/stop-all', async (req, res) => {
    try {
        const commandManager = req.app.get('commandManager');
        if (!commandManager) {
            return res.status(500).json({ error: 'Command manager not initialized' });
        }
        await commandManager.stopAllCommands();
        res.json({ message: 'All commands stopped successfully' });
    } catch (error) {
        logger.error('Error stopping all commands:', error);
        res.status(500).json({ error: error.message });
    }
});

// List running commands
router.get('/commands', async (req, res) => {
    try {
        const commandManager = req.app.get('commandManager');
        if (!commandManager) {
            return res.status(500).json({ error: 'Command manager not initialized' });
        }
        const commands = commandManager.getActiveCommands();
        res.json(commands);
    } catch (error) {
        logger.error('Error listing commands:', error);
        res.status(500).json({ error: error.message });
    }
});

module.exports = router; 