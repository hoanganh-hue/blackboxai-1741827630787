const express = require('express');
const router = express.Router();
const { exec } = require('child_process');
const pidusage = require('pidusage');
const ps = require('ps-node');
const { promisify } = require('util');
const { AppError } = require('../../middleware/errorHandler');
const { heavyApiLimiter } = require('../../middleware/rateLimit');
const { cache } = require('../../middleware/cache');
const AdvancedLogger = require('../../utils/advancedLogger');

const logger = new AdvancedLogger();
const psLookup = promisify(ps.lookup);
const execPromise = promisify(exec);

// List all processes
router.get('/list', heavyApiLimiter, cache(30), async (req, res, next) => {
    try {
        const processes = await psLookup({});
        const detailedProcesses = await Promise.all(
            processes.map(async (proc) => {
                try {
                    const usage = await pidusage(proc.pid);
                    return {
                        ...proc,
                        usage
                    };
                } catch (err) {
                    return proc;
                }
            })
        );

        res.json(detailedProcesses);
    } catch (error) {
        next(new AppError('Failed to list processes', 500, 'PROCESS_LIST_ERROR'));
    }
});

// Get process details
router.get('/:pid', heavyApiLimiter, cache(10), async (req, res, next) => {
    try {
        const { pid } = req.params;
        const processes = await psLookup({ pid: parseInt(pid) });
        
        if (!processes.length) {
            return next(new AppError('Process not found', 404, 'PROCESS_NOT_FOUND'));
        }

        const usage = await pidusage(pid);
        res.json({
            ...processes[0],
            usage
        });
    } catch (error) {
        next(new AppError('Failed to get process details', 500, 'PROCESS_DETAILS_ERROR'));
    }
});

// Kill process
router.delete('/:pid', heavyApiLimiter, async (req, res, next) => {
    try {
        const { pid } = req.params;
        const processes = await psLookup({ pid: parseInt(pid) });
        
        if (!processes.length) {
            return next(new AppError('Process not found', 404, 'PROCESS_NOT_FOUND'));
        }

        await new Promise((resolve, reject) => {
            ps.kill(pid, (err) => {
                if (err) reject(err);
                resolve();
            });
        });

        res.json({ message: `Process ${pid} killed successfully` });
    } catch (error) {
        next(new AppError('Failed to kill process', 500, 'PROCESS_KILL_ERROR'));
    }
});

// Start new process
router.post('/start', heavyApiLimiter, async (req, res, next) => {
    try {
        const { command } = req.body;
        
        if (!command) {
            return next(new AppError('Command is required', 400, 'MISSING_COMMAND'));
        }

        const { stdout, stderr } = await execPromise(command);
        res.json({
            message: 'Process started successfully',
            output: stdout,
            error: stderr
        });
    } catch (error) {
        next(new AppError('Failed to start process', 500, 'PROCESS_START_ERROR'));
    }
});

module.exports = router; 