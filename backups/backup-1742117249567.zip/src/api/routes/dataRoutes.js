const express = require('express');
const router = express.Router();
const FileAnalyzer = require('../../FileAnalyzer');
const path = require('path');
const fs = require('fs-extra');
const { v4: uuidv4 } = require('uuid');

// Khởi tạo FileAnalyzer
const fileAnalyzer = new FileAnalyzer();

// Lưu trữ các task đang chạy
const tasks = new Map();

// Phân tích một file
router.post('/analyze', async (req, res) => {
    try {
        const { filePath, options = {} } = req.body;
        if (!filePath) {
            return res.status(400).json({ error: 'filePath is required' });
        }

        const taskId = uuidv4();
        const task = {
            id: taskId,
            status: 'pending',
            progress: 0,
            startTime: new Date(),
            filePath
        };
        tasks.set(taskId, task);

        // Bắt đầu phân tích bất đồng bộ
        analyzeFileAsync(task, options).catch(error => {
            task.status = 'failed';
            task.error = error.message;
            task.endTime = new Date();
        });

        res.json({
            taskId,
            status: task.status,
            message: 'File analysis started'
        });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// Quét nhiều file
router.post('/scan', async (req, res) => {
    try {
        const { directory, patterns = [], recursive = false, options = {} } = req.body;
        if (!directory) {
            return res.status(400).json({ error: 'directory is required' });
        }

        const taskId = uuidv4();
        const task = {
            id: taskId,
            status: 'pending',
            progress: 0,
            startTime: new Date(),
            directory,
            stats: {
                totalFiles: 0,
                processedFiles: 0,
                errorFiles: 0
            },
            results: []
        };
        tasks.set(taskId, task);

        // Bắt đầu quét bất đồng bộ
        scanDirectoryAsync(task, patterns, recursive, options).catch(error => {
            task.status = 'failed';
            task.error = error.message;
            task.endTime = new Date();
        });

        res.json({
            taskId,
            status: task.status,
            message: 'Directory scan started'
        });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// Kiểm tra trạng thái task
router.get('/status/:taskId', (req, res) => {
    const { taskId } = req.params;
    const task = tasks.get(taskId);
    
    if (!task) {
        return res.status(404).json({ error: 'Task not found' });
    }

    res.json(task);
});

// Hàm phân tích file bất đồng bộ
async function analyzeFileAsync(task, options) {
    try {
        task.status = 'processing';
        
        // Phân tích file
        const result = await fileAnalyzer.analyzeFile(task.filePath);
        
        task.status = 'completed';
        task.progress = 100;
        task.result = result;
        task.endTime = new Date();
    } catch (error) {
        task.status = 'failed';
        task.error = error.message;
        task.endTime = new Date();
        throw error;
    }
}

// Hàm quét thư mục bất đồng bộ
async function scanDirectoryAsync(task, patterns, recursive, options) {
    try {
        task.status = 'processing';

        // Lấy danh sách file
        const files = await getFiles(task.directory, patterns, recursive);
        task.stats.totalFiles = files.length;

        // Phân tích từng file
        for (const file of files) {
            try {
                const result = await fileAnalyzer.analyzeFile(file);
                task.results.push({
                    path: file,
                    analysis: result
                });
                task.stats.processedFiles++;
            } catch (error) {
                task.stats.errorFiles++;
                console.error(`Error analyzing file ${file}:`, error);
            }
            task.progress = (task.stats.processedFiles / task.stats.totalFiles) * 100;
        }

        task.status = 'completed';
        task.endTime = new Date();
    } catch (error) {
        task.status = 'failed';
        task.error = error.message;
        task.endTime = new Date();
        throw error;
    }
}

// Hàm lấy danh sách file trong thư mục
async function getFiles(directory, patterns, recursive) {
    const files = [];
    
    async function scan(dir) {
        const entries = await fs.readdir(dir, { withFileTypes: true });
        
        for (const entry of entries) {
            const fullPath = path.join(dir, entry.name);
            
            if (entry.isDirectory() && recursive) {
                await scan(fullPath);
            } else if (entry.isFile()) {
                if (patterns.length === 0 || patterns.some(pattern => 
                    new RegExp(pattern.replace(/\*/g, '.*')).test(entry.name))) {
                    files.push(fullPath);
                }
            }
        }
    }
    
    await scan(directory);
    return files;
}

module.exports = router; 