const express = require('express');
const router = express.Router();
const multer = require('multer');
const path = require('path');
const fs = require('fs-extra');
const FileManager = require('../../utils/fileManager');
const AdvancedLogger = require('../../utils/advancedLogger');

const logger = new AdvancedLogger();
const fileManager = new FileManager(logger);

// Ensure uploads directory exists
const uploadsDir = path.join(__dirname, '../../uploads');
fs.ensureDirSync(uploadsDir);

// Configure multer for file upload
const storage = multer.diskStorage({
    destination: function (req, file, cb) {
        cb(null, uploadsDir);
    },
    filename: function (req, file, cb) {
        const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9);
        cb(null, file.fieldname + '-' + uniqueSuffix + path.extname(file.originalname));
    }
});

const upload = multer({ storage: storage });

// Upload file endpoint
router.post('/upload', upload.single('file'), async (req, res) => {
    try {
        if (!req.file) {
            return res.status(400).json({ error: 'No file uploaded' });
        }

        const fileInfo = {
            originalName: req.file.originalname,
            filename: req.file.filename,
            path: req.file.path,
            size: req.file.size,
            mimetype: req.file.mimetype
        };

        logger.info('File uploaded successfully:', fileInfo);
        res.json(fileInfo);
    } catch (error) {
        logger.error('Upload error:', error);
        res.status(500).json({ error: error.message });
    }
});

// List files endpoint
router.get('/list', async (req, res) => {
    try {
        const files = await fileManager.listFiles(uploadsDir);
        res.json(files);
    } catch (error) {
        logger.error('Error listing files:', error);
        res.status(500).json({ error: error.message });
    }
});

// Download file endpoint
router.get('/download/:filename', async (req, res) => {
    try {
        const filePath = path.join(uploadsDir, req.params.filename);
        if (!await fileManager.exists(filePath)) {
            return res.status(404).json({ error: 'File not found' });
        }
        res.download(filePath);
    } catch (error) {
        logger.error('Error downloading file:', error);
        res.status(500).json({ error: error.message });
    }
});

// Delete file endpoint
router.delete('/delete/:filename', async (req, res) => {
    try {
        const filePath = path.join(uploadsDir, req.params.filename);
        if (!await fileManager.exists(filePath)) {
            return res.status(404).json({ error: 'File not found' });
        }
        await fileManager.deleteFile(filePath);
        res.json({ message: 'File deleted successfully' });
    } catch (error) {
        logger.error('Error deleting file:', error);
        res.status(500).json({ error: error.message });
    }
});

module.exports = router;