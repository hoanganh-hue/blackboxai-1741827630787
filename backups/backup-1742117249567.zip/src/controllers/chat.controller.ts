import { Request, Response, NextFunction } from 'express';
import { ChatGPTService } from '../services/chatgpt.service';
import { ChatGPTConfig } from '../interfaces/chatgpt.interface';

export const chatCompletion = async (
  req: Request, 
  res: Response, 
  next: NextFunction
) => {
  try {
    const { message, config } = req.body;
    if (!message) {
      throw new Error('Message is required');
    }
    const chatGPTService = new ChatGPTService();
    const response = await chatGPTService.generateResponse(
      message,
      config as Partial<ChatGPTConfig>
    );
    res.json(response);
  } catch (error) {
    next(error);
  }
};