class Test:
    def __init__(self):
        self.name = "Test"
    def test(self):
        print("Test")
